package zoo;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;

public class Main {
 
  public static void main(String[] args) throws NoSuchAlgorithmException, IOException {
    Authentication userSession = new Authentication();
    userSession.authenticator();
    
   // Role userRole = new Role();
    
   // userSession();
    //userRole.printRole(userSession.sessionRole);
    
  }

private static void userSession() {
	// TODO Auto-generated method stub
	
}
  
}
